# Maintenance

- [Structure migration plan](structure-migration-plan.md): confirmed interview decisions, proposed migration stages, preservation requirements, verification, and optional delegation. Implementation has not started.
- [Previous structure audit](structure-audit.md): earlier layout changes, historical verification, and preserved evidence exceptions. Placement rules are being reconsidered under the current AGENT.md.

# CMS/CJH redesign interview

Status: CMS-only redesign interview. KHJ cancelled the CJH experiment and requested no further CJH discussion in this conversation. All CJH questions/proposals below are historical and inactive. Existing CMS experiment results remain withdrawn. No new inference is authorized by final design agreement yet. User invoked `grill-me` / `grilling`; ask one decision at a time and await the answer.

Current CJH source authority: KHJ explicitly rejected using data/항목표.json to design CJH inputs. Use CJH's selected original cards as the authority for judgment criteria and required reference material. The proposed union of card references and organizer-table references is withdrawn. Earlier mixed-source sizing is historical and cannot establish the current CJH input bundle or context requirement. See the final CJH authority decision below.

## Settled user instruction

- Substantive fidelity to CMS/CJH hypotheses is the top priority. No arbitrary experimenter interpretation, criteria, selection decisions, hypothesis improvements or silent resolution of ambiguity.
- The previous original-card experiment is withdrawn as evidence of hypothesis validity. Its raw artifacts remain historical audit records with `withdrawal.json`; report titles and navigation identify withdrawal. Original input/response/metric bytes remain unchanged. Do not use its scores or predictions to choose new hypothesis wording or decision rules.
- Read the authors’ selected original sources; never modify `user/`. CMS selection remains the 정리본 and CJH v10–v18 unless the user explicitly changes the source authority. Do not import the other CMS document or other colleagues’ criteria.
- The completed-run [Astra critique](../reports/cms-cjh-astra-completed-critique.md) motivates the redesign. Prior approved mechanisms are historical context, not proof of fidelity: output schema/parser, reference selection, independent-card context, truncation limits and scoring must be reexamined against this new priority. Do not silently carry over the former experiment-only context exception.
- No new public upload or publication of the withdrawn run as a valid evaluation. The earlier public-export approval request remains unanswered; the current task is redesign.

## Facts already found in original sources

CJH v10:52 and v12:51 name e10/e12 evidence fields, but the selected cards do not specify the prior custom top-level Korean JSON schema. CJH v15:44 and v17:43 state cross-item exclusivity. CMS 정리본:333 gives an instruction applying to other items. CJH v12:12 distinguishes absence from the competitive-product list; a top-k excerpt cannot establish full-list absence. These facts must not be replaced by root-authored interpretations.

## First unresolved dependency

Can KHJ obtain CMS/CJH’s own clarification for consequential details that their selected documents do not settle? Recommended process: document the exact ambiguity and source passage, obtain author clarification, and keep the dependent experiment decision unresolved until then. No answer has been received. This question does not authorize contacting the colleagues directly.

## Official field contract verified after KHJ correction

On 2026-09-13 KHJ pointed out that e10 is the competition-defined evidence field for v10. Verified the current official evaluation page (https://dacon.io/competitions/official/236754/overview/evaluation, sections 1, 2 and 3): CSV columns are id, v1..v24, e1..e24; v_i is the binary violation decision and e_i its evidence. Item10 is an absence-detection item whose evidence may be empty and is excluded from qualitative evidence evaluation. CJH v10:52 explicitly leaves e10 blank. This is a verifiable external contract, not author ambiguity or a choice for KHJ to make.

The supplied `data/정답스키마_디코딩.json` also defines per-item objects with 위반여부 and 근거문구, including a null evidence type for v10. The previous custom singleton top-level-only parser was not the supplied full schema. Do not describe these established field meanings as underspecified or ask the authors to redefine them. Separate the official CSV/JSON contract from any genuinely unstated hypothesis semantics; inspect organizer-provided facts before further interview questions. No replacement parser or inference has been implemented.

## Independent inference clarification

KHJ challenged the claimed need to extract common rules when judging items independently. Root acknowledged the error and withdrew its recommendation to switch to one joint judgment per author on that basis. Independent calls do not require extracting or rewriting rules. Providing the author's entire selected card source verbatim in each call, while specifying one target item, is a proposed way to preserve cross-item instructions; it has not yet been frozen as a complete input design. The earlier user decision for independent item judgments has not been replaced by a joint-inference decision.

Remaining design considerations: independent calls can still produce mutually inconsistent v15/v16 or v17/v18 decisions despite seeing the same original rules; preserve these observations rather than silently reconcile them. Keep generated answers out of other calls; cache reuse is limited to identical input prefixes. Verify full-input and output budgets without silently shortening originals, and agree an explicit response contract consistent with organizer fields before implementing its reader. Reference completeness and the selected CMS source's embedded dev answers remain experiment-wide issues, not reasons that independent inference requires rule extraction. These notes do not authorize a new run or resolve the outstanding design choices.

## KHJ decision: pair groups and full relation audit

KHJ explicitly instructed that v15/v16 and v17/v18 each be judged together, and requested all potentially contradictory item relations plus the location of CMS dev-answer notes. Grouping is now seven CJH groups [10], [11], [12], [13], [14], [15,16], [17,18] and six independent CMS groups. Other grouping has not been authorized. This supersedes singleton decisions only for the two named pairs; final run/input/output/reference design is still pending.

The [source relation catalog](cms-cjh-item-relations.md) covers all 105 unordered pairs within the selected 15-item scope, separating explicit exclusions, deductions under shared scope/facts, conditional cases, and pairs without a justified binary exclusion. It is documentation, not a prompt addition, repair mechanism or new evaluator. Grouping two items does not guarantee that the model follows exclusivity.

CMS dev-specific notes are the final v24 [주의] paragraphs at source lines 335 (PPS-DEV-062), 337 (PPS-DEV-071), and 339 (PPS-DEV-049). After inspecting their locations, KHJ instructed using the cards with precisely these three paragraphs excluded. This is now the agreed CMS input-source exception. Preserve the preceding general [주의] paragraph at line 333, all other CMS wording, and all selected CJH cards. Keep user/ originals unchanged; the eventual experiment input copy will record the original source and the exact three excluded paragraphs. Describe this as the CMS 정리본 with three KHJ-specified dev-case paragraphs excluded, not as a wholly unmodified source. Record the exclusion in the experiment report. No broader removal, rewriting or source substitution is authorized. This resolves the handling of the explicit notes, not the experiment's remaining design choices or any claim of an unseen holdout. No new experiment input or inference has been produced during this interview update.

## KHJ decision: organizer-shaped structured output

KHJ accepted using the organizer-provided JSON schema, retaining only the current group's items, with structured decoding. Keep each retained item's source structure/field types and binary choices. This is output-format enforcement; do not add cross-item logical constraints. In particular, (v15,v16)=(1,1) and (v17,v18)=(1,1) must remain representable so inconsistency can be observed rather than prevented or repaired by the decoder. Use the same agreed structure for generation and evaluation. The exact projected schema and prompt must be reviewable before execution. No new schema implementation, parser or inference was enacted during this update.

## Read-only sizing for the next reference decision

Measured 2026-09-13 with local models/gemma-4-26B-A4B-it-NVFP4/tokenizer.json using tokenizers.Tokenizer, no_truncation(), no_padding(), and add_special_tokens=False. The saved tokenizer has an 8,192-token truncation setting; measurements with that setting enabled are not full-input counts.

- Organizer CSV data/법령패키지/중기부고시/중기부고시_경쟁제품_세부품명.csv: 616 data rows, 75,014 bytes, 34,386 untruncated raw tokens (entire UTF-8 file, including header and all columns/special conditions).
- CJH v10–v18 originals concatenated in numeric order with their existing text: 5,616 raw tokens.
- Sizing-only serialization json.dumps(record, ensure_ascii=False) for each of the 200 original data/dev.jsonl records: maximum 33,633 tokens, PPS-DEV-169. No dev_labels file was opened.
- Component token-count sum for largest serialized notice + full CSV + all CJH cards: 73,635. This is not an actual finalized prompt count or a proven lower bound: no chat template, wrapper/schema, reference laws or output budget included, and tokenization across final boundaries can differ. No model generation or GPU capacity test was performed.

The full CSV alone exceeds the 32,768 default context, and the previous 36,864 exception applied only to the withdrawn experiment. KHJ has now explicitly approved full-catalog provision and enlarging context/KV capacity for this redesigned local experiment, with the departure from competition settings reported. This is new authorization for the redesigned experiment, not reuse of the old exception. The old candidate selector must not be reinstated.


## KHJ decision: full catalog and disclosed local context/KV extension

KHJ asked whether structured output means making the model output JSON; root clarified that generation is constrained to the agreed JSON structure, with judgments still chosen by the model. No additional semantic constraint was authorized.

KHJ instructed providing the entire competitive-product catalog and explicitly documenting that the experimenter enlarged KV capacity beyond competition settings. Use all 616 CSV rows, columns and special conditions, retaining the original header and source text; no notice-specific candidate selection or top-k reduction. Investigate and provision enough local context/KV capacity to preserve the agreed full input and output; the exact numerical settings are not yet selected or tested. This exception applies to the redesigned experiment and does not alter the default/submission configuration.

Official evaluation page rechecked 2026-09-13: https://dacon.io/competitions/official/236754/overview/evaluation, fixed-model section. Server max_model_len upper bound is 32,768; organizer baseline uses 16,384. The page does not provide a single fixed KV-cache byte allocation to compare against. Report the actual local max_model_len, actual KV allocation/capacity and dtype, and the context-limit departure separately; do not invent a server KV-memory figure or claim a larger byte allocation without evidence. Local runtime/model/hardware conditions must be visible when interpreting results.

Local config.json text_config.max_position_embeddings is 262,144 (read-only verification). This states the configured model position limit, not proof that the local GPU can fit the required context or 16 concurrent requests. No model load, GPU capacity probe or new inference was performed here. Final reference-law composition, prompt budgets, capacity feasibility and final shared design confirmation remain pending. Preserve the user's completion-driven max16/prefix-sharing objective while assessing capacity; do not silently lower it.

## KHJ request: size legal references before choosing

KHJ said the proposed organizer/card-cited legal-source scope seemed acceptable given the larger context, but explicitly asked for lengths before judging it. Treat this as authorization for measurement, not a final scope or numerical-context decision. The [sizing report](../reports/cms-cjh-reference-sizing.md) and [source-span/count record](cms-cjh-reference-sizing.json) contain the results.

Per-target-group legal bundles plus original notice serialization/whole author cards: maximum raw-component sums 65,330 CMS and 80,183 CJH using whole parent articles; literal cited-paragraph variant CJH maximum 79,936. CJH includes full CSV; CMS main totals omit it as an exposed suite-scope assumption, and CSV-in-CMS alternatives are also reported. Author-wide common-law bundles would yield 98,648 CMS / 83,272 CJH without CSV in CMS. These are sizing conventions, not final rendered prompt counts. Wrapper/schema/input formatting and output reserve are not included. Possible context sizes are not GPU-tested or selected.

The record exposes literal paragraph versus parent-article scope, item/group-only versus author-wide law scope, exact raw source spans, and missing/uncertain references (notably historical notified amounts and recursively referenced provisions). No missing reference or rule was invented. No new inference or operational runner was implemented. Await KHJ's decision on the reported composition and lengths before acting on dependent experiment work.

## KHJ correction: competitive-product CSV belongs only to CJH

KHJ correctly questioned whether both authors require the full competitive-product catalog. The selected CJH v10–v18 cards explicitly call for competitive/general-product comparison. The selected CMS v19–v24 cards and their organizer-table references do not. Full CSV provision is therefore CJH-only; CMS receives no CSV. Root's suggestion to consider adding it to CMS was unnecessary and is withdrawn. The sizing report now removes that alternative. Per-group maximum component sums remain CMS 65,330 and CJH 80,183 using whole parent articles. Do not use the withdrawn CMS+CSV scenario to recommend a larger context or to broaden CMS inputs. Legal-reference scope and actual context/GPU feasibility are still awaiting final decisions/checks.

## CMS revision discovered: 615e649e (explanation requested, adoption pending)

KHJ reported that CMS committed revised hypotheses and asked for an easy explanation. Fetched origin only; origin/master advanced to 615e649e80794556f9ae2d889da99d5c41a8cba4 (WIITYTILY0529, 2026-09-13 08:42:59 +09:00). Local branch/working files and user/ originals were not checked out, merged or changed. A separate untracked analysis/feature_exclusivity_20260913/ appeared in git status and is unrelated user/other-work state; do not alter it.

The commit adds three files under the existing CMS card directory: 원문_META_추출규칙_v19-v24.md (Unicode filename decomposed), 판정카드_v19-v24_토큰수_제한.md (decomposed), and candidates.jsonl (200 records, six per-item candidate sets each). Read both complete documents and candidate structure; recomputed candidate length/truncation aggregates without reading dev_labels.

Revised author-defined pipeline:
- Search all provided documents by item-specific keywords. Retain matching lines plus +/-2 lines for v19–v22/v24, +/-3 for v23; merge overlaps and retain original doc IDs/types, character offsets and line numbers.
- Cap candidate source at 1,800 characters/item. Prefer passages with more primary/secondary signal hits; a long line may retain its continuous beginning. Secondary signals generally score/contextualize rather than seed, except v23 date/amount and v24 comparison-axis signals also seed retrieval.
- Provide only item-relevant original META fields, preserving null/미입력/해당 없음. Pass input_completeness and dropped_doc_counts for every item. No candidate is an automatic answer.
- Each text block in the revised card document is an independent item prompt with {META}/{원문후보} substitutions. The total INPUT cap is 2,000 tokens including the chat template. Fixed cards embed CMS's summarized legal criteria/exceptions. Measure actual Gemma tokens; remove low-priority candidate passages if over budget, preserving fixed criteria/exceptions. Document's token table is a character-count/2 mock estimate, not measured rendered Gemma input.
- Output item-keyed JSON, e.g. {"v19":{"위반여부":0,"근거문구":null}}. Most cards explicitly submit 0 on uncertainty; v20 also submits0 when missing/unprocessed documents prevent absence determination, and v23 submits0 when required dates/documents are missing. v20 evidence is always null; other positive evidence must be <=500 characters, a continuous unchanged span in one original document. This is a substantive updated policy, not merely a shorter copy of the earlier card.

Uploaded candidates: all <=1,800 chars; budget_truncated counts v19..v24 = 7,3,24,0,156,70. Standard medians recomputed from candidate_chars = 67,0,195.5,0,1723,1458 (slightly different from explanatory table's 65,0,194,0,1718,1455). Root did not verify claimed positive/evidence recall or actual post-template 2,000-token compliance. The author explicitly calls v23 structured date/amount extraction and v24 per-axis reserved slots FUTURE improvements; do not implement them as if already part of the current method.

Reproduction/experimental caveats to preserve:
- The extraction note cites script/build_prompt_inputs_v19_v24.py, but that implementation and any build_prompt_inputs path are absent from the entire fetched commit tree. Ranking formula, exact keyword set/tie handling and final budget integration therefore cannot be claimed reproduced from these three files alone.
- Extraction note line3 names dev.jsonl AND dev_labels.csv as development sources; its recall check is dev-based. No unseen-data accuracy is established.
- Revised v24 prompt line169 still contains explicit PPS-DEV-062 and PPS-DEV-049 official-positive notes; the earlier three-paragraph exclusion applied to the old source and does not automatically define a deletion span for this new document. No edits were made to the revised source.
- If KHJ adopts this revision, the old full-CMS-card + original-law-bundle sizing/input design and agreed output-root projection must be reconsidered against CMS's new standalone prompts. Do not silently append the former wrapper/full-card/law bundle or change CMS's uncertainty policy. CJH's source and catalog plan remain unchanged by this CMS-only commit.

Current action was explanation only; adopting/executing this revised CMS hypothesis has not been authorized by a final shared design agreement. Commit: https://github.com/starpoem17/nara/commit/615e649e80794556f9ae2d889da99d5c41a8cba4

## KHJ authorization boundary and extraction explanation

KHJ explicitly authorizes experimenter judgment solely to exclude answer memos from model inputs, including the revised CMS source. All other arbitrary experimental judgments require KHJ's permission. Apply this to consequential choices in input selection, unspecified extraction details, prompt/rule changes and output handling; ordinary read-only inspection and documenting an already-made decision do not require renewed permission. Keep user/ originals unchanged. For the revised CMS standalone v24 text block, source line169 contains the explicit PPS-DEV-062/049 official-answer memo and falls within the authorized exclusion. Do not turn this into permission to remove ordinary author-written criteria/examples, alter candidate source text, or invent missing extraction behavior. No new model input was generated during this explanatory turn.

CMS's extraction note describes keyword-hit LINE windows, not a semantic sentence-boundary selection algorithm. Window +/-2 lines except v23 +/-3; overlapping windows merged; source positions retained; maximum1,800 characters/item with keyword-based priority and continuous-prefix truncation for a long line. Additional model-input limit2,000 tokens is checked after substitution/chat rendering, dropping low-priority candidate ranges while preserving fixed criteria. Secondary terms normally only contribute ranking/context; v23 date/amount and v24 comparison-axis search groups also seed candidate windows. These are author-stated procedures; exact match normalization/regex, score weights, tie handling and final formatting are not supplied by the absent implementation.

Concrete read-only verification against data/dev.jsonl: PPS-DEV-034 v19, original document D0 has the manufacturer supply/A/S commitment requirement on line137. Uploaded candidate covers lines135–139, 489 characters, exact text[3443:3932]. Both the character slice and original line slice match the uploaded text. Original blank lines136/138 count within the window. Other v19 candidates in the same record include A/S-plan/evaluation passages, so a keyword hit is a candidate rather than an automatic violation. This sampled check does not validate the entire extractor or its dev recall claims. No extra retrieval/scoring logic was implemented.

## KHJ decision: consume CMS's pre-extracted JSONL; exclude extraction time

KHJ instructed skipping extraction and directly using CMS's uploaded candidates.jsonl. Source is commit 615e649e80794556f9ae2d889da99d5c41a8cba4, path `user/CMS/판정카드v19_v24/candidates.jsonl`, SHA256 80259ee689e0b03888311d3a7fcb19cafff161be9408423317f15151f0f33c1b, 200 rows / 1,200 item inputs. Preserve CMS-selected META values, candidate segment text/order and provenance, input_completeness, and dropped_doc_counts. Do not rerun or reconstruct an extractor, rerank candidate segments, invent scoring/tie rules, or replace candidates with the full original notice. Original notices remain available for source/evidence validation; feeding extra original text into the model would be a separate design choice needing permission. This records the input-source decision; final rendering, budgets and full shared experiment design remain pending.

The hypothetical extraction tie issue is closed for this experiment because its selection stage has already been performed by CMS. Do not defer examples based on hypothetical historical ties, reconstruct missing candidate scores, or claim that no ties occurred. Uploaded item keys are ['budget_truncated', 'candidate_chars', 'dropped_doc_counts', 'input_completeness', 'meta', 'segments']; segment keys are ['doc_id', 'doc_type', 'end', 'line_end', 'line_start', 'start', 'text']. They contain selected segments/provenance, not original ranking scores or discarded tied candidates, so historical tie occurrence cannot be established from this artifact. If extraction is later reintroduced, KHJ's proposed tie-defer rule must be revisited with an explicit scoring definition and observable ties; it is not a reason to block current cached-input use.

Mandatory runtime disclosure for the experiment report:
“본 실험은 CMS가 사전에 생성한 candidates.jsonl을 사용하여 원문 후보 추출 단계를 재실행하지 않았다. 따라서 측정 시간에는 사전 추출 시간이 포함되지 않으며, 원문부터 추출·추론을 모두 수행하는 전체 처리시간보다 해당 단계만큼 짧게 측정된다. 사전 추출 시간은 미측정이며 전체 처리시간은 산출하지 않았다.”

Keep measured model inference, model load/input preparation/JSONL read, and extraction time categories explicit. Report extraction as skipped/not measured, not zero seconds, and do not invent a correction factor or full-pipeline total. This is inference on CMS's provided candidate artifacts, not a timing/reproduction test of CMS's extractor. No new inference was run in this decision update. Any further candidate deletion for a final input-token budget would be a separate selection step, not an automatically authorized consequence of using this JSONL; measure first and obtain KHJ approval for consequential choices.


## KHJ decision: plain-text CMS placeholder contents

KHJ explicitly chose plain text for the revised CMS card's existing [META]/{META} and [원문]/{원문후보} positions and approved the short example: META field-name/value lines followed by extracted original notice text. Keep the rest of the selected standalone text block unchanged except for the authorized answer-memo exclusion. candidates.jsonl remains the input data artifact; do not serialize its objects as JSON/JSONL inside these placeholders. The earlier root proposal to insert JSON objects was never approved and is superseded by this decision. Rechecked CMS's source: it specifies placeholder substitution, but no JSON/JSONL serialization for their contents; its explicit JSON instruction governs the model output.

The short example illustrates formatting, not permission to omit other selected META values, candidate segments, or author-required completeness information. Preserve source values and candidate text/order. No final rendered input, token measurement for this approved format, or inference has yet been produced.

KHJ accepted retaining the revised CMS cards' literal item-keyed output, e.g. {"v19":{"위반여부":0,"근거문구":null}}, after clarifying that the organizer schema adds outer fields 공고ID and 판정 and contains all 24 items. The substantive result fields remain 위반여부 and 근거문구; the outer wrapper difference does not require changing CMS's cards. Match structured decoding to the author-specified output structure, with format enforcement only and the model choosing judgments. Associate outputs with their known request notice/item during result collection. This supersedes the earlier organizer-root projection for CMS; CJH's agreed output design is unchanged. Do not claim empirically identical model predictions across different output formats; no such comparison was run. No schema implementation or inference has yet been performed.


## CMS plain-text sizing; next CJH reference decision

Read-only measurement on 2026-09-13: the revised six independent text blocks from 615e649e and the same uploaded candidates were rendered in memory. Excluded only the v24 line containing the PPS-DEV-062/049 answer memo. META uses original key/value lines; input_completeness and dropped_doc_counts use original keys/values with two-space nested indentation. Null/boolean values appear as null/true/false. Candidate segment text/order is unchanged, separated by two newline characters. This sizing convention does not include candidate doc-ID/type/position headers, candidate_chars or budget_truncated fields, extra law text, a system prompt, or schema instructions. Segment provenance and those other candidate fields remain in the source artifact; this calculation does not silently settle any further input-format additions/omissions. No inference or final input freeze occurred.

Used local AutoTokenizer with local_files_only=True, one user message, enable_thinking=False, add_generation_prompt=True, truncation=False, padding=False; disabled saved backend truncation/padding. Counted the actual input_ids and verified exact equality against untruncated backend encoding of the rendered chat for all 1,200 inputs. An initial sanity check counted the returned mapping's two fields rather than tokens; discarded that invalid result before reporting, then normalized to input_ids and performed the independent encoding comparison.

| Item | Inputs | Minimum | Median | Maximum | Over 2,000 |
|---|---:|---:|---:|---:|---:|
| v19 | 200 | 543 | 595 | 1,684 | 0 |
| v20 | 200 | 610 | 623 | 1,731 | 0 |
| v21 | 200 | 527 | 656.5 | 1,674 | 0 |
| v22 | 200 | 505 | 507 | 1,379 | 0 |
| v23 | 200 | 897 | 1,747 | 1,926 | 0 |
| v24 | 200 | 650 | 1,552.5 | 1,998 | 0 |

Maximum is PPS-DEV-189 v24 (seven candidate segments), with only two input tokens spare under this rendering. No further candidate selection or budget exception is needed for this measured text, and neither was performed. Any changed rendering must be recounted; do not claim these counts include unmeasured provenance headers or other additions. The 2,000-token author limit concerns input, so output tokens are outside this comparison.

The pending interview question now concerns CJH's legal-reference recipient scope: root recommends a common bundle of references explicitly cited by CJH cards and the organizer item table for all seven CJH groups. This is a recommendation only; earlier per-group attachment was not finalized and the common-bundle alternative was measured at 83,272 maximum raw-component tokens with full parent articles. That sum is not a final rendered prompt or GPU-feasibility result. Agreement on sharing the bundle does not silently decide paragraph-versus-parent-article coverage, historical notified amounts, recursive references, or numerical context/KV configuration. CMS's revised standalone prompts do not inherit the former whole-card/full-law bundle.


## KHJ decision: CJH cards alone govern hypothesis and reference requirements

KHJ: “항목표는 생각하지 말자. CJH의 가설을 실험하는 게 이번 목적이야. 절대 우리의 임의 판단으로 CJH의 가설 실험이 틀어져서는 안 돼.”

Withdraw root's proposal to union CJH-card citations with data/항목표.json citations. Do not use that table to add reference laws, change judgment criteria, resolve author ambiguity, or supplement CJH's hypothesis. CJH's selected original v10–v18 cards govern both their instructions and their reference requirements. Preserve requirements expressed in words as well as numbered citations: for example, competitive-product names/special conditions and the notice-date/contract-law/purchase-object-specific notified amount explicitly required by v14. Do not invent the corresponding selection/applicability rules when the source leaves them unstated; present any consequential unresolved choice to KHJ before acting. Authorization to exclude answer memos remains the sole standing permission for experimenter judgment.

The common-reference-bundle question was not approved. Both adding organizer-table references and the earlier per-group/author-wide mixed-source bundle configurations remain unapproved; do not treat this correction as permission to substitute a new bundle silently. The previous maximum raw-component figures (including 80,183 and 83,272 for CJH) were calculated using organizer-table-plus-card references, so they cannot be reused as the chosen current input budget. Any later author-only candidate composition must be exposed and measured on its own terms.

This correction concerns the authority for CJH's hypothesis/input design. Existing approved groups [10], [11], [12], [13], [14], [15,16], [17,18], the full competitive-product catalog, and agreed output-format handling were not replaced. Official field-format facts are not authorization to import organizer-table judgment/reference rules. No inference, new reference selection, or source-file edit was performed during this update.


## Next question: authority to supplement author-required notified-amount originals

Read-only inspection driven by CJH v14:13,26,44 (not the organizer item table): the card requires the notified amount appropriate to notice date, contract law and purchase object. All 200 dev dates are 20260102–20260720. META counts: national/goods33, national/general-services51, local/goods45, local/general-services71. No labels, predictions or outcome-based selection were used.

The provided package contains one standalone notified-amount file, titled `국가를 당사자로 하는 계약에 관한 법률 등의 재정경제부장관이 정하는 고시금액.txt`. Its preserved source header gives publication20260102, notice2026-439, effective20260108; it has no substantive text after the [부칙] label. One dev notice predates that effective date: PPS-DEV-18, date20260102, local contract law. This establishes a source-date question, not a different threshold, a violation, or proven legal inapplicability. Do not infer a uniform threshold, missing local rule, amount change or retrospective effect from the file name/date alone. No external source has been fetched or selected in this update.

Pending question for KHJ: permit using official historical notified-amount originals from the National Law Information Center when needed to fulfill the CJH card's own reference requirement beyond what is established by the provided package. Root recommends obtaining the applicable-source evidence and providing original text for the card-guided model judgment, with source/date/scope visible for review, rather than assigning thresholds to notices in experimenter code. This is a source-scope proposal only and is not yet approved. It does not authorize unrelated laws, organizer-table references, rule rewriting, a retrieval algorithm or a fallback judgment on incomplete information.


## Resolved: Dev18 date concern after KHJ-authorized label/source audit

KHJ explicitly requested analyzing Dev18's labels to test the practical significance of the January2/8 date difference. This authorizes this targeted label analysis; it is not permission to feed labels or label-derived rules into prompts. Root analyzed Dev18 only and independently compared official historical/current originals. The [audit report](../reports/cjh-dev18-notified-amount-check.md) owns the evidence and scope; [source texts/hashes](cjh-dev18-notified-amount-audit.json) retain the verification. All35 amount rows match, with only the minister name changing in the normalized numbered bodies. Provided package text matches the current official body. Dev18 P=204,246,000 and labels(v14,v15,v16)=(0,1,0) are consistent with the unchanged230,000,000 threshold.

The specific monetary-change concern is resolved: do not treat the January8 source header as a reason to block this dev200 experiment or require an external-reference-input exception. The previous external-original inclusion question remains unapproved but is no longer required on that premise. Root acknowledges that escalating a header-date discrepancy before checking its actual effect overstated the practical concern. No model prediction was generated and no prompt, source authority, rule, reference bundle or original source was modified. Disclose this user-authorized label audit in future experiment reporting; do not claim universal label-blind redesign preparation.


## Next question: SW Article48 delegated monetary provisions

Rechecked all nine CJH original cards without consulting the organizer item table. Each explicitly calls for 「소프트웨어 진흥법」제48조 application using 사업금액 구간. The provided Article48 (소프트웨어 진흥법.txt:388–398) does not itself state the20/40/80억원 numerical lower bounds; its paragraph2 explicitly refers to the amount notified by the science/ICT minister. The supplied 「중소 소프트웨어사업자의 사업 참여 지원에 관한 지침」 identifies Article48(2) as its authority in Article1, sends the amount to annex1 in Article2, and gives amount-application provisions in Article3. Annex1 is explicitly headed “제2조 및 제3조 관련” and contains the20/40/80억원 classes. These are verified source links, not experimenter-invented monetary rules.

Pending KHJ question: permit appending the original Article2, Article3 and annex1 of this supplied guideline alongside Article48 so the model can obtain the monetary ranges required by the CJH cards. Root recommends this concrete three-unit addition. It is not yet approved and does not authorize adding other statutes through the organizer table, recursively expanding every cross-reference, setting a threshold in code, rewriting exceptions, or deciding per-notice eligibility. The complete CJH reference bundle and recipient scope are still not frozen. Source readout alone is not an input-selection decision.


## Current scope: CMS updated hypothesis only; final design confirmation pending

KHJ cancelled CJH hypothesis validation for this conversation. Stop pursuing its reference, legal, grouping and runtime questions. Retain historical records without treating them as active work. CMS's original experiment remains withdrawn as hypothesis evidence; do not compare its defective-parser scores as a valid baseline.

The [CMS-only final proposal](cms-updated-cards-plan.md) consolidates the accepted revised source, cached candidates, plain-text placeholders, card-shaped structured output, independent dev200 calls and prior runtime choices. Root checked the original approved plan: thinkingOFF, temperature0, seed0 and output512 were already agreed, so do not ask for those permissions again merely because results were withdrawn. Revised CMS cards do not introduce alternative generation settings. The next interview question is final shared confirmation of the consolidated CMS design, not a new arbitrary rule or repeated approval of settled settings. After confirmation, perform the previously requested Astra-medium fidelity review within the CMS-only scope before inference. No review has yet been run for this final proposal.


## Explicit stop after confirmed-plan/Astra report

KHJ: “확정 계획을 서술하고 이에 대한 Astra medium의 가설 오염 검토를 내게 보고한 뒤 구현은 시작하지마. 내 승인을 기다려”. Current authorization is CMS plan documentation plus the requested Astra-medium independent read-only review and reporting. After reporting, wait for KHJ's explicit approval. Do not use the earlier eventual experiment objective as authorization to start implementation, generate frozen model inputs/schemas, change runners, run inference or publish during this turn. Findings must be reported faithfully; do not silently enact reviewer recommendations or alter the confirmed hypothesis.


## Astra medium completed review; implementation still withheld

The user-requested CMS-only independent review is complete: [verbatim Astra medium output](../reports/cms-updated-cards-astra-fidelity-review.md). Verdict is conditionally faithful within the cached-candidate dev200 inference scope. The substantive user-decision item is whether the text-only two-newline representation's document/segment boundary loss is acceptable or should be specified differently. The reviewer does not equate unspecified model-visible provenance with a definite source violation. The author artifact's truncated v20 candidates and dev development history are interpretation limits, not authorization to improve or replace them. Root preserved the review verbatim and added its status to the plan without changing the planned inputs or implementing the proposed experiment. Report plan/review to KHJ and wait for explicit implementation approval as instructed.


## Accepted scope limits; explanation requested, no implementation approval

KHJ accepted the extraction/full-pipeline exclusion and the absence of unseen-data generalization validation. KHJ then asked for accessible detailed explanations of v20 complete-observation versus candidate truncation, and the proposed omission of document/segment boundary metadata from the model input. Read-only examples and the distinction are recorded in the CMS-only plan. No input field/boundary change, implementation, inference or publication is authorized by these explanatory requests.


## KHJ specifies quoted candidate pieces; input-cap conflict pending

Root clarified that CMS specifies extraction/provenance preservation and placeholder locations but does not prescribe how several pieces are joined for model input. The old two-newline-only representation was root's choice, not author instruction or implied permission from generic plain-text approval. KHJ then explicitly selected quoted candidate pieces (`...는 다음과 같다. '후보1', '후보2', '후보3'`) and required the actual prompt in the experiment report for CMS review. Root acknowledged the short example using `추출된 원문 후보는 다음과 같다. ` and unchanged original pieces in uploaded order. This approves that presentation choice only; the implementation hold remains.

On KHJ's “다음 질문”, read-only in-memory remeasurement reproduced all prior baseline token summaries and verified chat-template token IDs against untruncated backend encodings. The new maxima v19..v24 are1707,1755,1684,1403,1936,2024. Only PPS-DEV-189/v24 (seven pieces) exceeds CMS's2,000-token input cap, by24. The [current plan](cms-updated-cards-plan.md) owns exact measurement details and the remaining empty-list representation issue. The pending next question is whether KHJ permits this narrow24-token exception with explicit disclosure; no exception, candidate trimming, deferral, implementation or inference has been applied.


## KHJ approves the one-case24-token exception

KHJ explicitly instructed preserving candidate originals and the chosen quoted-piece presentation, disclosing the overage in the experiment report, and allowing it for this case only. Approved scope: PPS-DEV-189/v24 input2,024 tokens,24 above CMS's2,000-token input cap including the chat template. Other inputs remain capped at2,000; no additional candidate selection or generalized cap increase is approved. The [current plan](cms-updated-cards-plan.md) records the exact report disclosure. This resolves the preceding token-conflict question only. Empty-candidate presentation remains unresolved, and implementation/inference/publication approval is still withheld.


## KHJ approves the empty-candidate sentence and its report disclosure

After confirming that CMS does not specify the empty-candidate display wording, KHJ explicitly approved `추출된 원문 후보가 없습니다.` and instructed reporting that this arbitrary presentation choice was user-authorized. Use this exact sentence at the original-text placeholder when the uploaded segments list is empty. It describes the candidate list only; retain CMS's authored judgment and uncertainty handling. There are438 such notice/item inputs (v19..v24 counts96,148,65,129,0,0). The [current plan](cms-updated-cards-plan.md) records mandatory report wording and final read-only length statistics. Recounting all1,200 inputs with the approved sentence found no additional cap breach; only the already authorized PPS-DEV-189/v24 remains at2,024. No runner, frozen inputs, schema, inference or publication was created; explicit implementation approval remains pending.


## Explicit implementation approval

After all identified CMS design choices were resolved and root linked the confirmed plan, KHJ answered ‘시작’ to the explicit implementation-start question. This lifts the earlier hold and authorizes the agreed CMS-only implementation, preflight and one-pass dev200 inference. Preserve all source, input, output and reporting conditions; do not reopen settled choices or add hypothesis improvements. The original eventual GitHub publication instruction remains, subject to checking the concrete CMS-only payload. Root applies codebase-design for implementation and delegates independent source alignment and evaluation implementation to the user-permitted Sol medium agents.
